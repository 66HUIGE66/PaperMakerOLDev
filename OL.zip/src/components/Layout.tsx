import React, { useState } from 'react';
import { Layout as AntLayout, Menu, Button, Space, Drawer, Grid, FloatButton } from 'antd';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  BookOutlined,
  FileTextOutlined,
  BarChartOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  ThunderboltOutlined,
  NodeIndexOutlined,
  PlayCircleOutlined,
  DatabaseOutlined,
  TrophyOutlined,
  UserOutlined,
  SettingOutlined,
  RobotOutlined
} from '@ant-design/icons';
import UserInfo from './UserInfo';
import { useAuth } from '../contexts/AuthContext';

const { Header, Sider, Content } = AntLayout;

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const screens = Grid.useBreakpoint();
  const isMobile = !screens.md;
  const isAdmin = user?.role === 'ADMIN';
  const headerHeight = isMobile ? 44 : 64;
  const siderOffset = isMobile ? 0 : (collapsed ? 0 : 200);

  const menuItems = [
    {
      key: '/start-practice',
      icon: <PlayCircleOutlined />,
      label: '开始练习',
    },
    {
      key: '/practice-records',
      icon: <TrophyOutlined />,
      label: '练习记录',
    },
    {
      key: '/ai-assistant',
      icon: <RobotOutlined />,
      label: 'AI助手',
    },
    // 如果不是管理员，显示"我的内容"模块
    ...(isAdmin ? [] : [{
      key: 'my-content',
      icon: <UserOutlined />,
      label: '我的内容',
      children: [
        {
          key: '/my-questions',
          icon: <BookOutlined />,
          label: '我的题库',
        },
        {
          key: '/my-papers',
          icon: <FileTextOutlined />,
          label: '我的试卷',
        },
        {
          key: '/my-subject-knowledge',
          icon: <NodeIndexOutlined />,
          label: '我的学科知识点',
        },
        {
          key: '/my-rules',
          icon: <SettingOutlined />,
          label: '我的规则',
        },
        {
          key: '/my-statistics',
          icon: <BarChartOutlined />,
          label: '学习统计',
        },
      ],
    }]),
    {
      key: 'system-content',
      icon: <DatabaseOutlined />,
      label: '系统内容',
      children: [
        {
          key: '/system-questions',
          icon: <BookOutlined />,
          label: '系统题库',
        },
        {
          key: '/system-papers',
          icon: <FileTextOutlined />,
          label: '系统试卷',
        },
        {
          key: '/system-subject-knowledge',
          icon: <NodeIndexOutlined />,
          label: '系统学科知识点',
        },
        {
          key: '/system-rules',
          icon: <SettingOutlined />,
          label: '系统规则',
        },
      ],
    },
    {
      key: '/generate',
      icon: <ThunderboltOutlined />,
      label: '智能组卷',
    },
    // 规则管理入口已拆分为“我的规则”和“系统规则”，移除旧的总览入口
  ];

  const handleMenuClick = ({ key }: { key: string }) => {
    navigate(key);
  };

  return (
    <AntLayout className="app-layout">
      <Sider 
        trigger={null} 
        collapsible 
        collapsed={collapsed}
        breakpoint="md"
        collapsedWidth={0}
        onBreakpoint={(broken) => {
          setCollapsed(broken);
        }}
        style={{
          background: '#fff',
          boxShadow: '2px 0 8px rgba(0, 0, 0, 0.1)',
          position: 'fixed',
          top: 0,
          left: 0,
          height: '100vh',
          zIndex: 1001,
          overflowY: 'auto'
        }}
      >
        <div style={{ 
          height: 64, 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          borderBottom: '1px solid #f0f0f0'
        }}>
          <div className="app-logo">
            {collapsed ? '智刷' : '智能组卷刷题系统'}
          </div>
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={handleMenuClick}
          style={{ border: 'none' }}
        />
      </Sider>
      <AntLayout style={{ marginLeft: siderOffset }}>
        <Header className="app-header" style={{ position: 'fixed', top: 0, right: 0, left: siderOffset, zIndex: 1000, height: headerHeight, lineHeight: `${headerHeight}px` }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => {
                if (isMobile) {
                  setDrawerOpen(true);
                } else {
                  setCollapsed(!collapsed);
                }
              }}
              style={{ fontSize: '16px', width: isMobile ? 44 : 64, height: isMobile ? 44 : 64 }}
            />
          </div>
          <Space>
            <UserInfo />
          </Space>
        </Header>
        <Content className="app-content" style={{ padding: isMobile ? 12 : undefined, marginTop: headerHeight }}>
          {children}
        </Content>
        <FloatButton.BackTop visibilityHeight={300} />
        <Drawer
          placement="left"
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          width={240}
          bodyStyle={{ padding: 0 }}
        >
          <Menu
            mode="inline"
            selectedKeys={[location.pathname]}
            items={menuItems}
            onClick={(e) => {
              handleMenuClick(e as any);
              setDrawerOpen(false);
            }}
            style={{ border: 'none' }}
          />
        </Drawer>
      </AntLayout>
    </AntLayout>
  );
};

export default Layout;
